import express from 'express';
import http from 'http';
import {Server } from "socket.io"
import {chatsDb, usersDb} from "./models/dataBase";
import {nanoid} from "nanoid";
import {ChatInterface, MessageInterface} from "./models";

const app = express();
const server = http.createServer(app);
const webSocketServer = new Server(server,{
    cors: {
        origin: "http://localhost:5173"
    }
});

app.get('/', (req, res) => {
    res.send('<h1>Hello world</h1>');
});



webSocketServer.on('connection', (socket) => {

    socket.on('user connected', ({id,name}: { id: string, name: string }) => {
        usersDb.push({name,id,chats:[]})
        // Добавляем пользователя в комнату с его идентификатором
        socket.join(id);
    });
    socket.on('disconnect', () => {
        console.log("user disconnect")
    });
    socket.on('check usersDB', () => {
       console.log(usersDb)
    });

    socket.on('check chatsDb', () => {
        console.log(chatsDb)
    });

    socket.on('send message', ({message,chatId,userId}:{ chatId: string, message: string,userId:string }) => {
        let chatMatch = chatsDb.find((chat) => chat.id === chatId)
        let chat:ChatInterface = chatMatch || {id:chatId,messages:[]}
        if(chatMatch){
            chat.messages = [...chatMatch.messages,{text:message,userId,id:nanoid(),addedAt:new Date().toUTCString()}]
        }
        else {
            chat.messages = [{text: message, userId, id: nanoid(), addedAt: new Date().toUTCString()}]
            chatsDb.push(chat)
        }
        const userIds = getUniqueIds(chat.messages)
        // Отправляем сообщение пользователю в его комнату
        userIds.forEach(id => webSocketServer.to(id).emit('update', chat))


    });


});

server.listen(3000, () => {
    console.log('listening on *:3000');
});

interface GetUniqueIdsObjectType {
    userId: string;
    [key: string]: any;
};
interface IdSet {
    [key: string]: boolean;
}

function getUniqueIds(arr: GetUniqueIdsObjectType[]): string[] {
    // Создаем объект для хранения уникальных идентификаторов
    const idSet = arr.reduce((acc, item) => {
        acc[item.userId] = true;
        return acc;
    }, {} as IdSet);

    // Возвращаем массив уникальных идентификаторов
    return Object.keys(idSet);
}
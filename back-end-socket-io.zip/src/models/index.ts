export interface MessageInterface {
    id: string
    text: string
    addedAt:string
    userId: string
}

export interface UserInterface {
    id:string
    name: string
    chats : string[]
}

export interface ChatInterface {
    id:string
    messages: MessageInterface[]
}

import {ChatInterface, UserInterface} from "./index";

export const usersDb : UserInterface[] = []
export const chatsDb : ChatInterface[] = []
